package com.example.mymealdabba.ui.connectuser;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.mymealdabba.databinding.FragmentConnectuserBinding;

public class ConnectUserFragment extends Fragment {
    private FragmentConnectuserBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        binding = FragmentConnectuserBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.lblWeAreSocial;

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
